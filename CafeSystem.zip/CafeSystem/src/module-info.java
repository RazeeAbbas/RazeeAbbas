/**
 * 
 */
/**
 * 
 */
module CafeSystem {
	requires java.desktop;
}